class GmtTutorials:
	
	description = """GNOME Terminal is a terminal emulation application where you can\n choose to play around with commands if you like.\nTo go there follow 'Applications'-> 'Accessories'-> 'Terminal'
				   """
	
	dictionary = {'Gnome Terminal' : [('Applications', 'Accessories', 'Terminal'), description]}

gmt_tut = GmtTutorials()
