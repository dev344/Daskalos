class GmtTutorials:
	
	description = """You can configure the Login Screen here\nTo go there follow 'System'-> 'Administration'-> 'Login Screen'
				   """
	
	dictionary = {'Login Screen' : [('System', 'Administration', 'Login Screen'), description]}

gmt_tut = GmtTutorials()
