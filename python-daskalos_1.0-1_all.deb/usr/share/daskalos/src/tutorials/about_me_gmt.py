class GmtTutorials:
	
	description = """You can set your personal information here and you can\nalso change your password.\nTo get there follow'System'-> 'Preferences'-> 'About Me'
				   """
	
	dictionary = {'About Me' : [('System', 'Preferences', 'About Me'), description]}

gmt_tut = GmtTutorials()
