class GmtTutorials:
	
	description = """Change system time date and timezone\nTo go there follow 'System'-> 'Administration'-> 'Time and Date''
				   """
	
	dictionary = {'Time and Date' : [('System', 'Administration', 'Time and Date'), description]}

gmt_tut = GmtTutorials()
