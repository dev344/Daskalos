class GmtTutorials:
	
	description = """In users and groups you can add and delete users and also set and \nchange passwords\nTo go there follow 'System'-> 'Administration'-> 'Users and Groups"""
	
	dictionary = {'Users and groups' : [('System', 'Administration', 'Users and Groups'), description]}

gmt_tut = GmtTutorials()
