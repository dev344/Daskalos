class GmtTutorials:
	
	description = """Synaptic is a graphical package management tool which enables\n you to install, upgrade and remove software packages in a user\n friendly way.\nTo go there follow 'System'-> 'Administration'-> 'Synaptic Package Manager'
				   """
	
	dictionary = {'Synaptic Package Manager' : [('System', 'Administration', 'Synaptic Package Manager'), description]}

gmt_tut = GmtTutorials()
