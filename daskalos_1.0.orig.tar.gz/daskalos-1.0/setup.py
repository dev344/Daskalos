#!/usr/bin/env python
from setuptools import setup, find_packages
import os
import glob 

data_files1 = glob.glob("src/ui/*")
data_files2 = glob.glob("src/screenshots/*")
data_files3 = glob.glob("src/tutorials/*")

setup(  name='daskalos',
        version='1.0',
        data_files=[('share/daskalos/src/ui/', data_files1),
        ('share/daskalos/src/screenshots/', data_files2),
        ('share/daskalos/src/tutorials/', data_files3)],
        scripts = ["daskalos"],
        author = "Devesh Yamparala",
        author_email = "dev344@gmail.com",
        description = ("Daskalos is an interactive help application for linux beginners."),
        license="GPL", 
 )

