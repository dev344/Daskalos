class GmtTutorials:
	
	description = """Using Rhythmbox Music Player you can play and organise/organize \nyour music collection .\nIf you don't see the window open even after clicking check in the \nsystem tray on the top-right .\nTo go there follow 'Applications'-> 'Sound & Video'-> 'Rhythmbox Music Player'"""
	
	dictionary = {'Rhythmbox Music Player' : [('Applications', 'Sound & Video', 'Rhythmbox Music Player'), description]}

gmt_tut = GmtTutorials()
