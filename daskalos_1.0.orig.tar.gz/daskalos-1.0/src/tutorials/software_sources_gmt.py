class GmtTutorials:
	
	description = """At software sources you can configure the sources for installable software\n and updates\nTo go there follow 'System'-> 'Administration'-> 'Software Sources'"""
	
	dictionary = {'Software Sources' : [('System', 'Administration', 'Software Sources'), description]}

gmt_tut = GmtTutorials()
