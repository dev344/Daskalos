class GmtTutorials:
	
	description = """Change and manage your network connection settings here.\nTo get there follow'System'-> 'Preferences'-> 'Network Connections'
				   """
	
	dictionary = {'Network Connections' : [('System', 'Preferences', 'Network Connections'), description]}

gmt_tut = GmtTutorials()
