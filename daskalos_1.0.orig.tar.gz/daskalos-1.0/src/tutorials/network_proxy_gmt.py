class GmtTutorials:
	
	description = """Set your network proxy preferences.\nTo get there follow'System'-> 'Preferences'-> 'Network Proxy'
				   """
	
	dictionary = {'Network Proxy' : [('System', 'Preferences', 'Network Proxy'), description]}

gmt_tut = GmtTutorials()
