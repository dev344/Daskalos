class GmtTutorials:
	
	description = """Network Tools is where you can view information about your network\nTo go there follow 'System'-> 'Administration'-> 'Network Tools'
				   """
	
	dictionary = {'Network Tools' : [('System', 'Administration', 'Network Tools'), description]}

gmt_tut = GmtTutorials()
