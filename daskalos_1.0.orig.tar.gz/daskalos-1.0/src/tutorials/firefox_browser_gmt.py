class GmtTutorials:
	
	description = """Firefox delivers safe, easy web browsing. A familiar user interface,\nenhanced security features including protection from online identity\n theft,and integrated search let you get the most out of the web.\nTo go there follow 'Applications'-> 'Internet' ->'Firefox Web Browser'
				   """
	
	dictionary = {'Firefox Web Browser' : [('Applications', 'Internet' ,'Firefox Web Browser'), description]}

gmt_tut = GmtTutorials()
