class GmtTutorials:
	
	description = """gedit is a text editor which supports most standard editor features,\n extending this basic functionality with other features not usually\n found in simple text editors. gedit is a graphical application which\n supports editing multiple text files in one window (known sometimes as\n tabs or MDI).\nTo go there follow 'Applications'-> 'Accessories'-> 'gedit Text Editor'"""
	
	dictionary = {'Gedit Text Editor' : [('Applications', 'Accessories', 'gedit Text Editor'), description]}

gmt_tut = GmtTutorials()
